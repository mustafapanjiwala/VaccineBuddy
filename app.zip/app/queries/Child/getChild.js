import * as firebase from "firebase"
import "firebase/firestore"
import { useQuery, useMutation } from "react-query"
import { COLLECTIONS } from "../../constants/collections"

const process = async (id) => {
    const collectionref = firebase.firestore().collection(COLLECTIONS.CHILDREN);
    const doc = await collectionref.doc(id).get();
    return { ...doc.data(), id: doc.id }
}

export const useGetChild = (id) => {
    return useQuery(["getChild", id], () => process(id))
}