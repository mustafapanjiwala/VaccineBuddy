import * as firebase from "firebase";
import "firebase/firestore"
import { useMutation, useQuery } from "react-query";
import { COLLECTIONS } from "../../constants/collections"

// const process = async (load) => {
//     if (load.child && load.age) {
//         const collectionref = firebase.firestore().collection(COLLECTIONS.CHILDREN);
//         const mainCollectionref = await collectionref.doc(load.child.id).collection(`${load.age}_weeks`).get()
//         return mainCollectionref.docs.map(doc => ({ ...doc.data(), id: doc.id }))
//     } return new Error("empty fields")
// }

const map = [
    0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14,
    15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28
]

const mapData = (data, map) => {
    return new Promise((resolve, rejet) => {
        let count = 0;
        let filled_data = map.map((_, i) => {
            if (data[count].id === i.toString()) {
                return data[count++];
            } else {
                return ""
            }
        })
        console.error("DATA FILTEREDE")
        console.log("SORTED DATA", data)
        let arr = []
        filled_data.forEach((d, i) => {
            arr[map[i]] = d.id
        })
        console.log("ARR,", arr)
        resolve("MOTHER FUCKER")
    })
}

const process = async (load) => {
    if (load.child) {
        const collectionref = firebase.firestore().collection(COLLECTIONS.CHILDREN);
        const mainCollectionref = await collectionref.doc(load.child.id).collection(COLLECTIONS.VACCINATED_VAC).get()
        const sorted_data = mainCollectionref.docs.map(doc => ({ ...doc.data(), due_on: doc.data().due_on.toDate(), given_on: doc.data().given_on.toDate(), id: doc.id })).sort((a, b) => {
            if (a < b) return -1
            if (a > b) return 1
            return 0;
        })
        // const deb = await mapData(sorted_data, map)
        // console.log("DEB", deb)
        return sorted_data
    } return new Error("empty fields")
}

export const useGetVaccinatedVaccines = (load) => {
    return useQuery(["useGetVaccinatedVaccines"], () => process(load))
}