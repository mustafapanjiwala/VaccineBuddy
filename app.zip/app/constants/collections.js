export const COLLECTIONS = {
    USERS: "users",
    CHILDREN: "children",
    VACCINES: "vaccines",
    VACCINATED_VAC: "vaccinated_vaccines"
}