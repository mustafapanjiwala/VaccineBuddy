export default {
    primary: '#79D1D7',
    black: '#000000',
    white: '#FFFFFF',
    textGrey: '#353535',
    grey2: '#ECECEC',
    grey3: '#F6F6F6',
    profileBlue: '#E2ECED',
    errorRed: '#eb4335', 
    transparent: 'transparent'
};
