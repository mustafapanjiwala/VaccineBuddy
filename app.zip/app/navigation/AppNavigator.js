// import React from 'react';
// import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
// import colors from './app/constants/colors';
// import { MaterialCommunityIcons } from '@expo/vector-icons';

// const Tab = createBottomTabNavigator();

// const AppNavigator = () => {
//     return (
//         <Tab.Navigator
//             tabBarOptions={{
//                 activeTintColor: '#00858D',
//                 inactiveTintColor: colors.white
//             }}
//             barStyle={{ backgroundColor: colors.primary }}
//         >
//             <Tab.Screen
//                 name="PhoneNumber"
//                 component={PhoneNumberScreen}
//                 options={{
//                     tabBarIcon: ({ size, color }) => (
//                         <MaterialCommunityIcons
//                             name="home"
//                             size={size}
//                             color={color}
//                         />
//                     )
//                 }}
//             />
//             <Tab.Screen name="UserDetails" component={UserDetails1} />
//         </Tab.Navigator>
//     );
// };

// export default AppNavigator;
